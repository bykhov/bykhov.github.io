dataFile = 'Howell1.csv';
outputImage = 'howell1_linear_least_squares.jpg';

opts = detectImportOptions(dataFile, 'Delimiter', ';');
T = readtable(dataFile, opts);

height = T.height;
weight = T.weight;
age = T.age;

validMask = isfinite(height) & isfinite(weight) & isfinite(age);
height = height(validMask);
weight = weight(validMask);
age = age(validMask);

X = [ones(size(height)), height, weight];
beta = X \ age;
ageHat = X * beta;
residuals = age - ageHat;
orthogonalityVector = X' * residuals;
predictionResidualDot = ageHat' * residuals;
orthogonalityRatio = norm(orthogonalityVector) / (norm(X, 'fro') * norm(residuals) + eps);
predictionResidualRatio = abs(predictionResidualDot) / (norm(ageHat) * norm(residuals) + eps);

ssRes = sum(residuals .^ 2);
ssTot = sum((age - mean(age)) .^ 2);
rSquared = 1 - ssRes / ssTot;
rmse = sqrt(mean(residuals .^ 2));

heightGrid = linspace(min(height), max(height), 40);
weightGrid = linspace(min(weight), max(weight), 40);
[HGrid, WGrid] = meshgrid(heightGrid, weightGrid);
ageGrid = beta(1) + beta(2) * HGrid + beta(3) * WGrid;
orthLabels = categorical({'1', 'height', 'weight', 'predicted age'});
orthValues = [orthogonalityVector(:); predictionResidualDot];

fig = figure('Color', 'w', 'Position', [100, 100, 1800, 520]);

subplot(1, 3, 1);
scatter3(height, weight, age, 34, age, 'filled');
hold on;
surf(HGrid, WGrid, ageGrid, 'FaceAlpha', 0.35, 'EdgeColor', 'none');
xlabel('Height');
ylabel('Weight');
zlabel('Age');
title({'Age from Height and Weight', sprintf('age = %.2f + %.3f*height + %.3f*weight', beta(1), beta(2), beta(3))});
grid on;
view(38, 25);
colormap turbo;
cb = colorbar;
cb.Label.String = 'Observed age';
legend('Observed samples', 'Least-squares plane', 'Location', 'best');
ax1 = gca;
ax1.Toolbar.Visible = 'off';

subplot(1, 3, 2);
scatter(ageHat, residuals, 32, weight, 'filled');
hold on;
yline(0, 'k--', 'LineWidth', 1.1);
xlabel('Predicted age');
ylabel('Residual (observed - predicted)');
title({'Residual check', sprintf('R^2 = %.3f, RMSE = %.3f years', rSquared, rmse)});
grid on;
cb2 = colorbar;
cb2.Label.String = 'Weight';
ax2 = gca;
ax2.Toolbar.Visible = 'off';

subplot(1, 3, 3);
bar(orthLabels, orthValues, 0.55, 'FaceColor', [0.2 0.55 0.75]);
hold on;
yline(0, 'k--', 'LineWidth', 1.1);
ylabel('Inner product with residual');
title({'Orthogonality check', sprintf('||X^T r|| / (||X||_F ||r||) = %.3e', orthogonalityRatio)});
grid on;
ax3 = gca;
ax3.Toolbar.Visible = 'off';

annotation('textbox', [0.2, 0.01, 0.6, 0.09], ...
    'String', sprintf(['Consistency check: residual mean = %.3f, residual std = %.3f, max |residual| = %.3f, ' ...
    '||X^T r||/(||X||_F||r||) = %.3e, |y_hat^T r|/(||y_hat||||r||) = %.3e'], ...
    mean(residuals), std(residuals), max(abs(residuals), [], 'omitnan'), orthogonalityRatio, predictionResidualRatio), ...
    'EdgeColor', 'none', 'HorizontalAlignment', 'center', 'FontSize', 10);

exportgraphics(fig, outputImage, 'Resolution', 200);

fprintf('Linear least-squares model for age from height and weight\n');
fprintf('beta = [%.6f, %.6f, %.6f]\n', beta(1), beta(2), beta(3));
fprintf('R^2 = %.6f\n', rSquared);
fprintf('RMSE = %.6f years\n', rmse);
fprintf('Residual mean = %.6f\n', mean(residuals));
fprintf('Residual std = %.6f\n', std(residuals));
fprintf('Max |residual| = %.6f\n', max(abs(residuals)));
fprintf('X'' * residuals = [%.6e, %.6e, %.6e]\n', orthogonalityVector(1), orthogonalityVector(2), orthogonalityVector(3));
fprintf('predicted_age'' * residuals = %.6e\n', predictionResidualDot);
fprintf('Normalized orthogonality ratio = %.6e\n', orthogonalityRatio);
fprintf('Normalized prediction-residual ratio = %.6e\n', predictionResidualRatio);

if rSquared < 0.5
    fprintf('Inspection note: the fit is weak; height and weight alone do not explain age consistently with a linear model.\n');
else
    fprintf('Inspection note: the fit is reasonably consistent for a simple linear model.\n');
end

if orthogonalityRatio < 1e-12 && predictionResidualRatio < 1e-12
    fprintf('Orthogonality note: residuals are numerically orthogonal to the columns of X and to the fitted prediction, as expected for least squares.\n');
else
    fprintf('Orthogonality note: orthogonality is not numerically tight; inspect scaling or numerical conditioning.\n');
end
