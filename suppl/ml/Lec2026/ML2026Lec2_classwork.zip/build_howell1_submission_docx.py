from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "Howell1_submission_summary.docx"
IMAGE = ROOT / "howell1_linear_least_squares.jpg"


def set_paragraph_rtl(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    bidi = OxmlElement("w:bidi")
    bidi.set(qn("w:val"), "1")
    p_pr.append(bidi)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT


def set_run_rtl(run):
    run.font.name = "Arial"
    run.font.size = Pt(12)
    r_pr = run._r.get_or_add_rPr()
    rtl = OxmlElement("w:rtl")
    rtl.set(qn("w:val"), "1")
    r_pr.append(rtl)


def add_rtl_paragraph(document, text="", style=None, bold=False, font_size=12, align=WD_ALIGN_PARAGRAPH.RIGHT):
    paragraph = document.add_paragraph(style=style)
    set_paragraph_rtl(paragraph)
    paragraph.alignment = align
    run = paragraph.add_run(text)
    set_run_rtl(run)
    run.bold = bold
    run.font.size = Pt(font_size)
    return paragraph


def add_rtl_bullet(document, text):
    paragraph = document.add_paragraph(style="List Bullet")
    set_paragraph_rtl(paragraph)
    run = paragraph.add_run(text)
    set_run_rtl(run)
    return paragraph


def main():
    document = Document()

    section = document.sections[0]
    section.start_type = WD_SECTION.NEW_PAGE
    section.top_margin = Inches(0.75)
    section.bottom_margin = Inches(0.75)
    section.left_margin = Inches(0.8)
    section.right_margin = Inches(0.8)

    title = add_rtl_paragraph(
        document,
        "סיכום עבודה: התאמת מודל ליניארי בשיטת ריבועים פחותים לנתוני Howell1",
        bold=True,
        font_size=16,
        align=WD_ALIGN_PARAGRAPH.CENTER,
    )
    title.runs[0].font.name = "Arial"

    add_rtl_paragraph(document, "מטרת העבודה", bold=True, font_size=14)
    add_rtl_paragraph(
        document,
        "מטרת העבודה הייתה להתאים מודל ליניארי בשיטת הריבועים הפחותים עבור חיזוי גיל "
        "על סמך שני משתני קלט: גובה ומשקל. כלומר, הוגדרו X = (height, weight) והפלט הוא y = age.",
    )

    add_rtl_paragraph(document, "שיטת העבודה", bold=True, font_size=14)
    add_rtl_bullet(document, "נקרא קובץ הנתונים Howell1.csv והוצאו ממנו העמודות height, weight ו-age.")
    add_rtl_bullet(document, "נבנתה מטריצת תכן עם איבר חופשי: X = [1, height, weight].")
    add_rtl_bullet(document, "וקטור המקדמים חושב באמצעות פתרון least squares: beta = X \\ y.")
    add_rtl_bullet(document, "חושבו התחזיות, השאריות, מדדי R^2 ו-RMSE, ונשמר גרף JPEG.")

    add_rtl_paragraph(document, "המודל שהתקבל", bold=True, font_size=14)
    add_rtl_paragraph(
        document,
        "המודל הליניארי שהתקבל הוא: age = -27.164 + 0.298·height + 0.431·weight",
    )

    add_rtl_paragraph(document, "תוצאות עיקריות", bold=True, font_size=14)
    add_rtl_bullet(document, "R^2 = 0.478")
    add_rtl_bullet(document, "RMSE = 14.97 שנים")
    add_rtl_bullet(document, "ממוצע השאריות קרוב מאוד לאפס, כמצופה ממודל least squares.")
    add_rtl_bullet(document, "השגיאה המקסימלית בערך מוחלט היא 53.16 שנים.")

    add_rtl_paragraph(document, "בדיקת אורתוגונליות", bold=True, font_size=14)
    add_rtl_paragraph(
        document,
        "לפי תכונת הריבועים הפחותים, וקטור השאריות r = y - ŷ צריך להיות מאונך למרחב העמודות של X. "
        "לכן נבדק התנאי X^T r ≈ 0, וכן נבדק גם ŷ^T r ≈ 0.",
    )
    add_rtl_bullet(document, "X^T r = [-6.04e-12, -8.46e-10, -2.15e-10]")
    add_rtl_bullet(document, "ŷ^T r = -1.78e-10")
    add_rtl_bullet(document, "יחס אורתוגונליות מנורמל: 7.33e-16")
    add_rtl_bullet(document, "מסקנה: תנאי האורתוגונליות מתקיים מספרית, ולכן פתרון ה-least squares תקין.")

    add_rtl_paragraph(document, "פירוש הגרפים", bold=True, font_size=14)
    add_rtl_paragraph(
        document,
        "בגרף התלת-ממדי ניתן לראות את נקודות המדגם ואת המישור המותאם. "
        "בגרף השאריות ניתן לראות שהשאריות אינן מפוזרות באופן אקראי סביב האפס, אלא מציגות מבנה ועקמומיות. "
        "לכן, למרות שהפתרון המתמטי נכון, המודל הליניארי הפשוט אינו מתאר היטב את הקשר בין גיל לבין גובה ומשקל בלבד.",
    )

    if IMAGE.exists():
        add_rtl_paragraph(document, "איור: תוצאות ההתאמה והבדיקות", bold=True, font_size=14)
        picture = document.add_picture(str(IMAGE), width=Inches(6.7))
        last_paragraph = document.paragraphs[-1]
        set_paragraph_rtl(last_paragraph)
        last_paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER

    add_rtl_paragraph(document, "מסקנה סופית", bold=True, font_size=14)
    add_rtl_paragraph(
        document,
        "המודל שנבנה עומד בתנאי האורתוגונליות של שיטת הריבועים הפחותים, ולכן החישוב תקין מבחינה מתמטית. "
        "עם זאת, איכות ההתאמה בינונית בלבד, ולכן גובה ומשקל לבדם אינם מספיקים כדי לחזות גיל בצורה ליניארית טובה בנתונים אלה.",
    )

    document.save(OUTPUT)
    print(f"Created {OUTPUT}")


if __name__ == "__main__":
    main()
