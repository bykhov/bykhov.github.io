clearvars
clf

global sigmoid
sigmoid = @(x) 1./(1+exp(-x));

%% Dataset
data = load('ex2data1.txt');
X_raw = data(:, [1, 2]); y = data(:, 3);
M = size(X_raw,1);  % number of rows in the dataset
X = [ones(M,1), X_raw(:,1), X_raw(:,2)];

%%
function w = logistic_gd(X,y,w0,alpha)
    global sigmoid
    M = size(X,1);
    dw = 1e10;
    w = w0;
    while abs(max(dw)) > 1e-2
        dw = (1/M)*X'*(sigmoid(X*w)-y);
        w = w - alpha*dw;
    end
end

w = logistic_gd(X,y,0.1*ones(size(X,2),1),0.1);

% linear regression line
w2 = lsqminnorm(X,y);
%% Plot dataset
% Find Indices of Positive and Negative Examples
pos = y==1; 
neg = ~pos;
pos_c = sigmoid(X*w)>=0.5;
neg_c = ~pos_c;

%plot_x = [min(X(:,2))-2,  max(X(:,2))+2];
plot_x = [min(X(:,2))-2,  90];


% Calculate the decision boundary line
plot_y = (-1./w(3)).*(w(2).*plot_x + w(1));
plot_y2 = (-1./w2(3)).*(w2(2).*plot_x + w2(1));


figure(1)
clf
hold on;
plot(X_raw(pos, 1), X_raw(pos, 2), 'k+','LineWidth', 2, ...
    'MarkerSize', 6);
plot(X_raw(neg, 1), X_raw(neg, 2), 'ko', 'MarkerFaceColor', 'y', ...
    'MarkerSize', 5);
plot(X_raw(xor(pos,pos_c), 1), X_raw(xor(pos,pos_c), 2), '.r', 'MarkerFaceColor', 'r', ...
'MarkerSize', 10);
plot(plot_x, plot_y)
%plot(plot_x, plot_y2)
hold off
xlabel('$\mathbf{x}_1$','Interpreter','latex')
ylabel('$\mathbf{x}_2$','Interpreter','latex')
legend('y = 1', 'y = 0','Errors','Decision Boundary')

exportgraphics(gcf,'logistic_regression_2d_example.pdf')


%% 
pos_c = sigmoid(X*w)>=0.75;
neg_c = sigmoid(X*w)<=0.25;
figure(2)
clf
subplot(211)
hold on;
plot(X_raw(pos, 1), X_raw(pos, 2), 'k+','LineWidth', 1, ...
    'MarkerSize', 6);
plot(X_raw(pos_c, 1), X_raw(pos_c, 2), 'b+','LineWidth', 2, ...
    'MarkerSize', 6);
plot(plot_x, plot_y)
legend('y = 1 $(75\%>y\ge 50\%)$', 'y = 1 $(100\%\ge y\ge 75\%)$','Decision Boundary',Location='best')
xlabel('$\mathbf{x}_1$','Interpreter','latex')
ylabel('$\mathbf{x}_2$','Interpreter','latex')
subplot(212)
hold on
plot(X_raw(neg, 1), X_raw(neg, 2), 'ko', 'MarkerFaceColor', 'y', ...
    'MarkerSize', 5);
plot(X_raw(neg_c, 1), X_raw(neg_c, 2), 'ko', 'MarkerFaceColor', 'g', ...
    'MarkerSize', 5);
plot(plot_x, plot_y)
xlabel('$\mathbf{x}_1$','Interpreter','latex')
ylabel('$\mathbf{x}_2$','Interpreter','latex')
legend('y = 0 $(25\%<y<50\%)$', 'y = 0 $(0\%\le y\le 25\%)$','Decision Boundary',Location='best')

exportgraphics(gcf,'logistic_regression_2d_prob.pdf')

%% Loss function
J = 1/M*(-y'*log(sigmoid(X*w)) - (1-y)'*log(1-sigmoid(X*w)));

%% RoC and AUC
rocObj = rocmetrics(y,sigmoid(X*w),{'1'});
plot(rocObj)
exportgraphics(gcf,'roc.pdf')



