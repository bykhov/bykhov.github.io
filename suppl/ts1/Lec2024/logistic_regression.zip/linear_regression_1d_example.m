clearvars 
close all
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesFontName','Times New Roman')
set(groot,'defaultAxesFontSize',12)
set(groot,'defaultAxesXGrid','on')
set(groot,'defaultAxesYGrid','on')

%% Dataset 1
X = [ones(1,20); 10:29]';
y = [ones(1,10) zeros(1,10)]';

% linear regression line
w = lsqminnorm(X,y);

%% Plot 
figure(1)
subplot(211)

plot(X(:,2),y,'o')
hold on
plot(X(:,2),X*w>0.5,'.')

xx = [ones(1,length(10:.01:29)); 10:.01:29]';
plot(xx(:,2),xx*w,'-')
hold off
ylim([-0.1 1.1])
xlabel('$\mathbf{x}_1$','Interpreter','latex')
ylabel('$y$')
legend('$\hat{y}$', ...
    'Decision', ...
    'Boundary','Location','best');

%% Dataset 2
% asymmetric dataset
X = [ones(1,30); [(10:29) (60:69)]]';
y = [ones(1,10) zeros(1,20)]';

% linear regression line
w = lsqminnorm(X,y);

subplot(212)

plot(X(:,2),y,'o')
hold on
plot(X(:,2),X*w>0.5,'.')

xx = [ones(1,length(10:.1:69)); 10:.1:69 ]';
plot(xx(:,2),xx*w,'-')
hold off
ylim([-0.1 1.1])
xlabel('$\mathbf{x}_1$','Interpreter','latex')
legend('$\hat{y}$', ...
    'Decision', ...
    'Boundary','Location','best');

%exportgraphics(gcf,'linear_regression_1d_example.pdf')