clearvars
close all
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesFontName','Times New Roman')
set(groot,'defaultAxesFontSize',12)
set(groot,'defaultAxesXGrid','on')
set(groot,'defaultAxesYGrid','on')

global sigmoid
sigmoid = @(x) 1./(1+exp(-x));

%% Dataset 1
data = load('ex2data2.txt');
X_raw = data(:, [1, 2]); y = data(:, 3);

function out = mapFeature(X1, X2,degree)
% MAPFEATURE Feature mapping function to polynomial features
%
%   MAPFEATURE(X1, X2) maps the two input features
%   to quadratic features used in the regularization exercise.
%
%   Returns a new feature array with more features, comprising of
%   X1, X2, X1.^2, X2.^2, X1*X2, X1*X2.^2, etc..
%
%   Inputs X1, X2 must be the same size
%

out = [];
for i = 0:degree
    for j = 0:degree
        out(:, end+1) = (X1.^i).*(X2.^j);
    end
end
end
degree = 2;
X = mapFeature(X_raw(:,1), X_raw(:,2),degree);

%%
function w = logistic_gd(X,y,w0,alpha)
global sigmoid
[M, N] = size(X);
dw = 1e10;
w = w0;
while abs(max(dw)) > 1e-3
    dw = (1/M)*X'*(sigmoid(X*w)-y);
    w = w - alpha*dw;
end
end

w = logistic_gd(X,y,0.1*ones(size(X,2),1),0.1);

%% Plot
u = linspace(-1, 1.5, 50);
v = linspace(-1, 1.5, 50);

z = zeros(length(u), length(v));
% Evaluate z = theta*x over the grid
for i = 1:length(u)
    for j = 1:length(v)
        z(i,j) = mapFeature(u(i), v(j),degree)*w;
    end
end
z = z'; % important to transpose z before calling contour

% Plot z = 0
% Notice you need to specify the range [0, 0]

% Find Indices of Positive and Negative Examples
pos = y==1; 
neg = ~pos;
pos_c = sigmoid(X*w)>=0.5;
neg_c = ~pos_c;

%%
figure(1)
clf
hold on
% Plot Examples
plot(X_raw(pos, 1), X_raw(pos, 2), 'k+','LineWidth', 2, ...
'MarkerSize', 6);
plot(X_raw(neg, 1), X_raw(neg, 2), 'ko', 'MarkerFaceColor', 'y', ...
'MarkerSize', 5);
plot(X_raw(xor(pos,pos_c), 1), X_raw(xor(pos,pos_c), 2), '.r', 'MarkerFaceColor', 'r', ...
'MarkerSize', 10);

xlabel('$\mathbf{x}_1$','Interpreter','latex')
ylabel('$\mathbf{x}_2$','Interpreter','latex')
contour(u, v, z, [0, 0], 'LineWidth', 2)
legend('y = 1', 'y = 0','Errors','Boundary')
hold off

%exportgraphics(gcf,'logistic_regression_poly_example.pdf')