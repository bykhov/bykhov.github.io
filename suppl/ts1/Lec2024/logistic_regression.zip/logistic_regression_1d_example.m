clearvars 
close all
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesFontName','Times New Roman')
set(groot,'defaultAxesFontSize',12)
set(groot,'defaultAxesXGrid','on')
set(groot,'defaultAxesYGrid','on')

global sigmoid
sigmoid = @(x) 1./(1+exp(-x));

%% Dataset 1
X = [ones(1,20); 10:29]';
y = [ones(1,10) zeros(1,10)]';

%% 
function w = logistic_gd(X,y,w0,alpha)
    % Gradient descent (GD) minimization
    % X:    dataset
    % y:    classes
    % w0:   initial value for weights
    % alpha:GD parameter
    global sigmoid
    % M - number of elements (rows) in dataset
    % N - number of features (columns) in dataset
    [M, N] = size(X);   
    dw = 1e10;  % initial value for derivative 
    w = w0;     % initial value for weights
    while abs(max(dw)) > 1e-3   % stopping condition based on derivative value
        dw = (1/M)*X'*(sigmoid(X*w)-y); % derivative
        w = w - alpha*dw;   % update of weights
    end
end

w = logistic_gd(X,y,0.1*ones(size(X,2),1),0.1);

%% Plot 
figure(1)
subplot(211)
plot(X(:,2),y,'o')
hold on
plot(X(:,2),sigmoid(X*w)>0.5,'.')

xx = [ones(1,length(10:.01:29)); 10:.01:29]';
plot(xx(:,2),sigmoid(xx*w),'-',LineWidth=1.25)
hold off
ylim([-0.1 1.1])
xlabel('$\mathbf{x}_1$','Interpreter','latex')
legend('$y$', ...
    'Decision', ...
    '$\hat{y}=\sigma(\mathbf{Xw})$','Location','best');

%% Dataset 2
X = [ones(1,30); [(10:29) (60:69)]]';
y = [ones(1,10) zeros(1,20)]';

w = logistic_gd(X,y,0.1*ones(size(X,2),1),0.1);

%% Plot 
subplot(212)
plot(X(:,2),y,'o')
hold on
plot(X(:,2),sigmoid(X*w)>0.5,'.')

xx = [ones(1,length(10:.1:69)); 10:.1:69 ]';
plot(xx(:,2),sigmoid(xx*w),'-')
hold off
ylim([-0.1 1.1])
xlabel('$\mathbf{x}_1$','Interpreter','latex')
legend('$y$', ...
    'Decision', ...
    '$\hat{y}=\sigma(\mathbf{Xw})$','Location','best');

%exportgraphics(gcf,'logistic_regression_1d_example.pdf')