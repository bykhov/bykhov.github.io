clearvars
close all
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesFontName','Times New Roman')
set(groot,'defaultAxesFontSize',12)
set(groot,'defaultAxesXGrid','on')
set(groot,'defaultAxesYGrid','on')

%%
load co2.mat

[r,lags] = xcov(co2);
r = r(lags>=0);
lags = lags(lags>=0);
figure(1)
subplot(211)
plot(date_ym,co2)
xlabel('Date')
ylabel('x[n]')
title('$CO_2$')

subplot(212)
plot(lags,r)
[pks,loc] = findpeaks(r);
M = lags(loc(1));
hold on
plot(M,r(M),'o','MarkerFaceColor','r')
hold off
xline(M,'--')
xlabel('k')
ylabel('$R_\mathbf{x}[k]$')
set(gca, 'XTick', sort([M, get(gca, 'XTick')]));


subplot(211)
hold on
plot(date_ym(1:M:end),co2(1:M:end),'.','MarkerSize',10)
hold off

exportgraphics(gcf,'seasonality_analysis.pdf')